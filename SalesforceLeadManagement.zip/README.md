# Salesforce CRM for Lead Management

## Overview
This project demonstrates how to manage leads using Salesforce CRM through a Java application. It leverages the Salesforce REST API to authenticate, create, and manage leads in Salesforce.

## Features
- Authenticate with Salesforce using OAuth2.
- Create a new lead with basic details (First Name, Last Name, Email, Company, Status).
- Display lead creation results.

## Prerequisites
- Java 8 or higher
- Apache Maven
- Salesforce Account with API access
- Git (optional for version control)

## Setup Instructions
1. **Clone the repository**:
   ```bash
   git clone https://github.com/your-username/SalesforceLeadManagement.git
   ```
2. **Navigate to the project directory**:
   ```bash
   cd SalesforceLeadManagement
   ```
3. **Update `application.properties`** with your Salesforce credentials.
4. **Build the project**:
   ```bash
   mvn clean install
   ```
5. **Run the application**:
   ```bash
   mvn exec:java -Dexec.mainClass="com.example.salesforce.LeadManager"
   ```

## Configuration
Edit the `application.properties` file in the `src/main/resources` directory to set up your Salesforce credentials.

## License
This project is licensed under the MIT License.
