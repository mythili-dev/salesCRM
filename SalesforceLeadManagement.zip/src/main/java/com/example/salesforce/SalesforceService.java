package com.example.salesforce;

import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.apache.http.entity.StringEntity;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.Properties;

public class SalesforceService {
    private String accessToken;
    private String instanceUrl;

    // Load Salesforce credentials from application.properties
    private final Properties properties = new Properties();

    public SalesforceService() {
        try {
            properties.load(getClass().getClassLoader().getResourceAsStream("application.properties"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Login to Salesforce to get the access token
    public void login() throws IOException {
        String clientId = properties.getProperty("salesforce.clientId");
        String clientSecret = properties.getProperty("salesforce.clientSecret");
        String username = properties.getProperty("salesforce.username");
        String password = properties.getProperty("salesforce.password");

        String loginUrl = "https://login.salesforce.com/services/oauth2/token";
        CloseableHttpClient httpClient = HttpClients.createDefault();

        HttpPost post = new HttpPost(loginUrl);
        StringEntity params = new StringEntity(
                "grant_type=password&client_id=" + clientId +
                "&client_secret=" + clientSecret +
                "&username=" + username +
                "&password=" + password
        );
        post.setHeader("Content-Type", "application/x-www-form-urlencoded");
        post.setEntity(params);

        try (CloseableHttpResponse response = httpClient.execute(post)) {
            String json = EntityUtils.toString(response.getEntity());
            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);
            this.accessToken = node.get("access_token").asText();
            this.instanceUrl = node.get("instance_url").asText();
        }
    }

    // Method to create a new lead in Salesforce
    public String createLead(String firstName, String lastName, String email, String company, String status) {
        String url = instanceUrl + "/services/data/v54.0/sobjects/Lead";
        CloseableHttpClient httpClient = HttpClients.createDefault();

        try {
            HttpPost post = new HttpPost(url);
            post.setHeader("Authorization", "Bearer " + accessToken);
            post.setHeader("Content-Type", "application/json");

            // JSON payload to create a lead
            String jsonPayload = String.format(
                    "{"FirstName":"%s", "LastName":"%s", "Email":"%s", "Company":"%s", "Status":"%s"}",
                    firstName, lastName, email, company, status
            );
            post.setEntity(new StringEntity(jsonPayload));

            try (CloseableHttpResponse response = httpClient.execute(post)) {
                String jsonResponse = EntityUtils.toString(response.getEntity());
                ObjectMapper mapper = new ObjectMapper();
                JsonNode responseNode = mapper.readTree(jsonResponse);

                // If lead creation was successful, return the lead ID
                if (responseNode.has("id")) {
                    return "Lead created successfully with ID: " + responseNode.get("id").asText();
                } else {
                    // If there's an error, return the error message
                    return "Error creating lead: " + jsonResponse;
                }
            }
        } catch (IOException e) {
            return "Error creating lead: " + e.getMessage();
        }
    }
}
