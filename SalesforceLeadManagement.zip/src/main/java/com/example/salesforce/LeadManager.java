package com.example.salesforce;

import java.util.Scanner;

public class LeadManager {
    public static void main(String[] args) {
        SalesforceService service = new SalesforceService();
        Scanner scanner = new Scanner(System.in);

        try {
            // Log in to Salesforce
            service.login();
            System.out.println("Logged into Salesforce successfully.");

            // Prompt user for Lead details
            System.out.print("Enter Lead First Name: ");
            String firstName = scanner.nextLine();
            System.out.print("Enter Lead Last Name: ");
            String lastName = scanner.nextLine();
            System.out.print("Enter Lead Email: ");
            String email = scanner.nextLine();
            System.out.print("Enter Lead Company: ");
            String company = scanner.nextLine();
            System.out.print("Enter Lead Status: ");
            String status = scanner.nextLine();

            // Create Lead
            String response = service.createLead(firstName, lastName, email, company, status);
            System.out.println(response);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
}
